package io.redspace.ironsspellbooks.item;

import io.redspace.ironsspellbooks.api.spells.SpellRarity;
import io.redspace.ironsspellbooks.registries.ItemRegistry;
import io.redspace.ironsspellbooks.util.ItemPropertiesHelper;
import net.minecraft.ChatFormatting;
import net.minecraft.core.Holder;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.material.Fluid;

import java.util.List;

public class InkItem extends Item {
    private final SpellRarity rarity;
    private final Holder<Fluid> fluid;

    public InkItem(SpellRarity rarity, Holder<Fluid> fluid) {
        super(ItemPropertiesHelper.material());
        this.rarity = rarity;
        this.fluid = fluid;
    }

    public SpellRarity getRarity() {
        return rarity;
    }

    public static InkItem getInkForRarity(SpellRarity rarity) {
        return switch (rarity) {
            case COMMON -> (InkItem) ItemRegistry.INK_COMMON.get();
            case UNCOMMON -> (InkItem) ItemRegistry.INK_UNCOMMON.get();
            case RARE -> (InkItem) ItemRegistry.INK_RARE.get();
            case EPIC -> (InkItem) ItemRegistry.INK_EPIC.get();
            case LEGENDARY -> (InkItem) ItemRegistry.INK_LEGENDARY.get();
            default -> (InkItem) ItemRegistry.INK_COMMON.get();
        };
    }

    public Holder<Fluid> fluid() {
        return fluid;
    }

    @Override
    public void appendHoverText(ItemStack pStack, TooltipContext context, List<Component> lines, TooltipFlag pIsAdvanced) {
        super.appendHoverText(pStack, context, lines, pIsAdvanced);
        lines.add(Component.translatable("tooltip.irons_spellbooks.ink_tooltip", rarity.getDisplayName()).withStyle(ChatFormatting.GRAY));
    }
}
